import React from 'react';
import { render } from 'react-dom';
import Root from './Root';
import './index.css';

render(<Root />, document.getElementById('root'));
